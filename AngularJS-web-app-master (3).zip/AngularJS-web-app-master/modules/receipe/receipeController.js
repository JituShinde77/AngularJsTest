angular.module('receipe.controller', [])
.controller('indexController', ['$scope', function($scope){
    $scope.message = 'hello index';
}])