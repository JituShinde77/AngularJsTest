angular.module('book.controller', [])
.controller('tableCtrl', function($scope, $http){
            $scope.Books = [
                { BookId: 1, BookName: "Wealth of Nations", Author: "Adam Smith" },
                { BookId: 2, BookName: "Mudassar Khan", Author: "India" },
                { BookId: 3, BookName: "Suzanne Mathews", Author: "France" },
                { BookId: 4, BookName: "Robert Schidner", Author: "Russia" }
                ];
    
                $http.get("http://localhost:3000/helloworld")
                .then(function(response){
                    console.log(response.data.json);
                });
    });
    /*
    .controller('indexController', ['$scope', function($scope){
    $scope.message = 'hello index';
    }]);
    
    app.controller('bookController', ['$scope',function($scope){
        $scope.message = 'hello book';
    }]);

    */